import React from 'react';

interface Props {
  color: string;
  isOpponent?: boolean;
}

const gradients: Record<string, [string, string]> = {
  gold: ['#FFD700', '#FFA500'],
  blue: ['#1E90FF', '#00008B'],
  red: ['#FF6347', '#8B0000']
};

export default function ConePreview({ color, isOpponent }: Props) {
  const [main, alt] = gradients[color] || gradients['gold'];
  const gradient = isOpponent
    ? `linear-gradient(135deg, ${alt}, ${main})`
    : `linear-gradient(135deg, ${main}, ${alt})`;

  return (
    <div
      style={{
        width: '80px',
        height: '120px',
        margin: '10px auto',
        borderRadius: '10px',
        background: gradient,
        boxShadow: '0 4px 8px rgba(0,0,0,0.2)'
      }}
    />
  );
}