import React, { useState } from 'react';
import ConePreview from './components/ConePreview';

export default function App() {
  const [color, setColor] = useState('gold');

  return (
    <div style={{ textAlign: 'center', padding: '20px' }}>
      <h1>Conetoe Game</h1>
      <ConePreview color={color} isOpponent={false} />
      <ConePreview color={color} isOpponent={true} />
      <div style={{ marginTop: '20px' }}>
        <button onClick={() => setColor('gold')}>Gold</button>
        <button onClick={() => setColor('blue')}>Blue</button>
        <button onClick={() => setColor('red')}>Red</button>
      </div>
    </div>
  );
}